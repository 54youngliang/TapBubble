﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BubbleInit {

	public int order;
	public double result;
	public string view="11111";
	public Vector3 localPosition;
	public Vector3 localScale = new Vector3(1f,1f,1f);



}
