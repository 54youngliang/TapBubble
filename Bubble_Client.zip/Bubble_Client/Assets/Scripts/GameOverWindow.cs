﻿using UnityEngine;
using System.Collections;

public class GameOverWindow : MonoBehaviour {

	public HomeWindow homeWindow;
	public UILabel LevelLabel;


	public void ShowHome()
	{
		Debug.Log ("GameOver click home");
		homeWindow.ShowHomeWindow ();
	}

	public void StartAgain()
	{
		homeWindow.BeginMission ();
	}

}
