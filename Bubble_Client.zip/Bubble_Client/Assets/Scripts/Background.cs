﻿using UnityEngine;
using System.Collections;

public class Background : MonoBehaviour {

	public GameObject earth;
}
