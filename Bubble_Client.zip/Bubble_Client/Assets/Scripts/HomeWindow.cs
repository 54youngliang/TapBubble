﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HomeWindow : MonoBehaviour {

	[SerializeField]
	public GameObject background;
	public UIButton playButton;
	public GameController gameController;
	public GameObject pauseWindow;
	public GameObject gameOverWindow;
	public GameObject levelPassedWindowObject;

	private Vector3 playButtonOriginScale ;
	private bool backgroundHasMoved=false;
	private bool buttonHasScaled=false;


	// Use this for initialization
	void Start () {
		background.GetComponent<GestureEvent>().OnLeft = ShowLevelWindow;
		playButtonOriginScale = playButton.gameObject.transform.localScale;
	}

	public void ShowHomeWindow()
	{
		UpdateGameOverWindowStatus (false);
		UpdatePauseWindow (false);
		UpdateShowLevelComplete (false);
		playButton.gameObject.transform.localScale = playButtonOriginScale;
		playButton.enabled = true;
		playButton.gameObject.SetActive (true);
	}

	public void FirstBeginMission()
	{
		UpdatePauseWindow (false);
		TweenY tween = TweenY.Add (background, 1f, 300f);
		tween.OnComplete += BeginMission;
		backgroundHasMoved = true;

	}

	public void BeginMission()
	{
		UpdateGameOverWindowStatus (false);
		UpdatePauseWindow (false);
		UpdateShowLevelComplete (false);
		if (buttonHasScaled) {
			gameController.BeginMission ();
		} else {
			TweenScale scale = TweenScale.Begin (playButton.gameObject, 1f, Vector3.zero);
			playButton.enabled = false;
			scale.AddOnFinished(HiddenPlayButton);
			scale.AddOnFinished(gameController.BeginMission);
			buttonHasScaled = true;
		}

	}

	public void MissionFailed()
	{
		UpdateGameOverWindowStatus (true);
	}



	public void MissionComplete(int level,int star)
	{
		levelPassedWindowObject.SetActive (true);
		LevelPassedWindow window = levelPassedWindowObject.GetComponent<LevelPassedWindow> ();
		window.Show (level, star);
	}

	private void HiddenPlayButton(){
		playButton.gameObject.SetActive (false);
	}

	private void ShowLevelWindow()
	{
		var width = AppMain.Instance.uiRoot.manualWidth;
		AppMain.Instance.LevelWindow.transform.localPosition = new Vector3(width, 0, 0);
		AppMain.Instance.LevelWindow.gameObject.SetActive(true);
		TweenX.Add(AppMain.Instance.LevelWindow.gameObject, 0.5f, 0f).OnComplete += ShowLevelWindow;
		TweenX.Add(this.gameObject, 0.5f, -width);
	}

	private void UpdateGameOverWindowStatus(bool active)
	{
		gameOverWindow.SetActive (active);
	}
	
	private void UpdatePauseWindow(bool active)
	{
		pauseWindow.SetActive (active);
	}
	
	private void UpdateShowLevelComplete(bool active)
	{
		levelPassedWindowObject.SetActive (active);
	}
}
