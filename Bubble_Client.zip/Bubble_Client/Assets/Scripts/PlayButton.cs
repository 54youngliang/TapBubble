﻿using UnityEngine;
using System.Collections;

public class PlayButton : MonoBehaviour {

	public UISprite playBackground;
	public UISprite playLabel;
	public PlayAnimation playAnimation;
	public UIButton uiButton;
}
