﻿using UnityEngine;
using System.Collections;

namespace Uween
{
	public delegate void Callback();
}