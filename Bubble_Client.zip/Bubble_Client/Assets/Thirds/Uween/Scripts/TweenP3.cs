﻿using UnityEngine;
using System.Collections;

public class TweenP3 : TweenXYZ
{
}