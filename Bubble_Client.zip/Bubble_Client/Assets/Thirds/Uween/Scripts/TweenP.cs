﻿using UnityEngine;
using System.Collections;

public class TweenP : TweenXY
{
}
