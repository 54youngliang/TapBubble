﻿using UnityEngine;
using System.Collections;

public class TweenR3 : TweenRXYZ
{
}