﻿using UnityEngine;
using System.Collections;

public class TweenS : TweenSXY
{
}